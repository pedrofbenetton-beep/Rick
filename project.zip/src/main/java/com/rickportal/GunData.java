package com.rickportal;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;

import java.util.ArrayList;
import java.util.List;

public record GunData(PortalMode mode, boolean hasTarget, String dim, double x, double y, double z,
                      float scale, List<Waypoint> waypoints, List<Waypoint> history) {

    public record Waypoint(String name, String dim, double x, double y, double z) {}

    public static final String DEFAULT_DIM = "minecraft:overworld";
    public static final float[] SCALES = {0.75f, 1.0f, 1.5f, 2.0f};
    public static final int MAX_WAYPOINTS = 16;
    public static final int MAX_HISTORY = 10;

    public static int scaleIndex(float s) {
        int best = 1;
        float bd = Float.MAX_VALUE;
        for (int i = 0; i < SCALES.length; i++) {
            float d = Math.abs(SCALES[i] - s);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    public static GunData read(ItemStack stack) {
        NbtComponent comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp == null) {
            return new GunData(PortalMode.LIFO, false, DEFAULT_DIM, 0, 64, 0, 1.0f, new ArrayList<>(), new ArrayList<>());
        }
        NbtCompound n = comp.copyNbt();
        String dim = n.getString("Dim");
        if (dim.isEmpty()) dim = DEFAULT_DIM;
        float scale = n.contains("Scale") ? SCALES[scaleIndex(n.getFloat("Scale"))] : 1.0f;
        return new GunData(PortalMode.byName(n.getString("Mode")), n.getBoolean("HasTarget"), dim,
                n.getDouble("X"), n.contains("Y") ? n.getDouble("Y") : 64, n.getDouble("Z"),
                scale,
                fromNbt(n.getList("Waypoints", NbtElement.COMPOUND_TYPE)),
                fromNbt(n.getList("History", NbtElement.COMPOUND_TYPE)));
    }

    public void write(ItemStack stack) {
        NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> {
            nbt.putString("Mode", mode.name());
            nbt.putBoolean("HasTarget", hasTarget);
            nbt.putString("Dim", dim);
            nbt.putDouble("X", x);
            nbt.putDouble("Y", y);
            nbt.putDouble("Z", z);
            nbt.putFloat("Scale", scale);
            nbt.put("Waypoints", toNbt(waypoints));
            nbt.put("History", toNbt(history));
        });
    }

    private static NbtList toNbt(List<Waypoint> list) {
        NbtList out = new NbtList();
        for (Waypoint w : list) {
            NbtCompound c = new NbtCompound();
            c.putString("Name", w.name());
            c.putString("Dim", w.dim());
            c.putDouble("X", w.x());
            c.putDouble("Y", w.y());
            c.putDouble("Z", w.z());
            out.add(c);
        }
        return out;
    }

    private static List<Waypoint> fromNbt(NbtList list) {
        List<Waypoint> out = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            NbtCompound c = list.getCompound(i);
            out.add(new Waypoint(c.getString("Name"), c.getString("Dim"), c.getDouble("X"), c.getDouble("Y"), c.getDouble("Z")));
        }
        return out;
    }

    /** Formato simples para mandar os locais salvos pela rede: nome|dim|x|y|z;nome|dim|x|y|z */
    public static String encode(List<Waypoint> list) {
        StringBuilder sb = new StringBuilder();
        for (Waypoint w : list) {
            if (sb.length() > 0) sb.append(';');
            sb.append(clean(w.name())).append('|').append(w.dim()).append('|')
                    .append(w.x()).append('|').append(w.y()).append('|').append(w.z());
        }
        return sb.toString();
    }

    public static List<Waypoint> decode(String s) {
        List<Waypoint> out = new ArrayList<>();
        if (s == null || s.isEmpty()) return out;
        for (String part : s.split(";")) {
            String[] p = part.split("\\|");
            if (p.length != 5) continue;
            try {
                out.add(new Waypoint(clean(p[0]), p[1], Double.parseDouble(p[2]), Double.parseDouble(p[3]), Double.parseDouble(p[4])));
            } catch (NumberFormatException ignored) {
            }
            if (out.size() >= MAX_WAYPOINTS) break;
        }
        return out;
    }

    private static String clean(String name) {
        String n = name.replace('|', ' ').replace(';', ' ').trim();
        return n.length() > 16 ? n.substring(0, 16) : n;
    }
}
