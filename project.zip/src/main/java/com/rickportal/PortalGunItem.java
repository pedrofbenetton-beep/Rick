package com.rickportal;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.List;
import java.util.function.Consumer;

public class PortalGunItem extends Item {
    /** Preenchido pelo cliente para abrir a tela de configuração (evita carregar classes de cliente no servidor). */
    public static Consumer<ItemStack> OPEN_CONFIG = s -> {};

    public PortalGunItem(Settings settings) {
        super(settings);
    }

    public static ItemStack findGun(PlayerEntity p) {
        ItemStack main = p.getMainHandStack();
        if (main.getItem() instanceof PortalGunItem) return main;
        ItemStack off = p.getOffHandStack();
        if (off.getItem() instanceof PortalGunItem) return off;
        return ItemStack.EMPTY;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (player.isSneaking()) {
            if (world.isClient) OPEN_CONFIG.accept(stack);
            return TypedActionResult.success(stack, false);
        }
        if (!world.isClient && player instanceof ServerPlayerEntity sp) {
            PortalService.shoot(sp, (ServerWorld) world, stack);
        }
        player.getItemCooldownManager().set(this, 10);
        return TypedActionResult.success(stack, world.isClient);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        GunData d = GunData.read(stack);
        tooltip.add(Text.literal("Modo: " + d.mode().label).formatted(Formatting.GREEN));
        tooltip.add(Text.literal(d.hasTarget()
                ? String.format("Destino: %s  %.0f %.0f %.0f", d.dim(), d.x(), d.y(), d.z())
                : "Destino: não definido").formatted(Formatting.GRAY));
        tooltip.add(Text.literal("Botão direito: abrir portal").formatted(Formatting.DARK_GRAY));
        tooltip.add(Text.literal("Shift + botão: mapa e configurações").formatted(Formatting.DARK_GRAY));
    }
}
