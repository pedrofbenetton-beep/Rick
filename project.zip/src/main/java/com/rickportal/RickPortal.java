package com.rickportal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

public class RickPortal implements ModInitializer {
    public static final String MOD_ID = "rickportal";

    // Caixa grande o bastante para o portal na escala máxima (2x)
    public static final EntityType<PortalEntity> PORTAL_ENTITY = Registry.register(
            Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "portal"),
            FabricEntityTypeBuilder.<PortalEntity>create(SpawnGroup.MISC, PortalEntity::new)
                    .dimensions(EntityDimensions.fixed(4.0f, 5.0f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(10)
                    .build());

    public static final Item PORTAL_GUN = Registry.register(
            Registries.ITEM, Identifier.of(MOD_ID, "portal_gun"),
            new PortalGunItem(new Item.Settings().maxCount(1)));

    /** Bulbo de fluido de portal: combustível (16 tiros), fica na outra mão. */
    public static final Item PORTAL_FLUID = Registry.register(
            Registries.ITEM, Identifier.of(MOD_ID, "portal_fluid"),
            new Item(new Item.Settings().maxDamage(16)));

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(Payloads.Save.ID, Payloads.Save.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Extras.ID, Payloads.Extras.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Clear.ID, Payloads.Clear.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Destruct.ID, Payloads.Destruct.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Save.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            ItemStack gun = PortalGunItem.findGun(player);
            if (gun.isEmpty()) return;
            GunData old = GunData.read(gun);

            boolean has = !payload.dim().isEmpty();
            String dim = GunData.DEFAULT_DIM;
            double x = 0, y = 64, z = 0;
            if (has) {
                Identifier id = Identifier.tryParse(payload.dim());
                boolean finite = Double.isFinite(payload.x()) && Double.isFinite(payload.y()) && Double.isFinite(payload.z());
                if (id == null || !finite || context.server().getWorld(RegistryKey.of(RegistryKeys.WORLD, id)) == null) {
                    has = false;
                } else {
                    dim = id.toString();
                    x = Math.max(-29999999, Math.min(29999999, payload.x()));
                    z = Math.max(-29999999, Math.min(29999999, payload.z()));
                    y = Math.max(-2048, Math.min(4096, payload.y()));
                }
            }
            new GunData(PortalMode.byName(payload.mode()), has, dim, x, y, z,
                    old.scale(), old.waypoints(), old.history()).write(gun);
        });

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Extras.ID, (payload, context) -> {
            ItemStack gun = PortalGunItem.findGun(context.player());
            if (gun.isEmpty()) return;
            GunData old = GunData.read(gun);
            float scale = GunData.SCALES[GunData.scaleIndex(payload.scale())];
            List<GunData.Waypoint> wps = new ArrayList<>();
            for (GunData.Waypoint w : GunData.decode(payload.waypoints())) {
                Identifier id = Identifier.tryParse(w.dim());
                if (id != null && Double.isFinite(w.x()) && Double.isFinite(w.y()) && Double.isFinite(w.z())) wps.add(w);
            }
            new GunData(old.mode(), old.hasTarget(), old.dim(), old.x(), old.y(), old.z(),
                    scale, wps, old.history()).write(gun);
        });

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Clear.ID,
                (payload, context) -> PortalService.clearAll(context.player()));

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Destruct.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            ItemStack gun = PortalGunItem.findGun(p);
            if (gun.isEmpty()) return;
            gun.decrement(1);
            p.getServerWorld().createExplosion(null, p.getX(), p.getY() + 0.5, p.getZ(), 3.0f,
                    World.ExplosionSourceType.NONE);
            p.sendMessage(Text.literal("A arma se autodestruiu!"), true);
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(PORTAL_GUN);
            entries.add(PORTAL_FLUID);
        });
    }
}
