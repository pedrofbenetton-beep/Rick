package com.rickportal;

public enum PortalMode {
    LIFO("LIFO", "Pilha: no limite (3), apaga o portal mais novo."),
    FIFO("FIFO", "Fila: no limite (3), apaga o portal mais antigo."),
    PAIRS("MULTIPAIRS", "4 portais ligados em pares, em ordem. O 2º de cada par abre no destino (se definido)."),
    BASE("BASE", "Todos os portais levam ao mesmo destino. Limite de 10.");

    public final String label;
    public final String description;

    PortalMode(String label, String description) {
        this.label = label;
        this.description = description;
    }

    public PortalMode next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public static PortalMode byName(String name) {
        try {
            return valueOf(name);
        } catch (Exception e) {
            return LIFO;
        }
    }
}
