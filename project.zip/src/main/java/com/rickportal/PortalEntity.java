package com.rickportal;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;

import java.util.UUID;

public class PortalEntity extends Entity {
    private static final TrackedData<Boolean> CLOSING =
            DataTracker.registerData(PortalEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final TrackedData<Float> SCALE =
            DataTracker.registerData(PortalEntity.class, TrackedDataHandlerRegistry.FLOAT);
    public static final int OPEN_TICKS = 10;

    private UUID owner;
    private UUID partner;
    private PortalMode mode = PortalMode.LIFO;
    private long created;
    private boolean hasDest;
    private String destDim = "";
    private double dx, dy, dz;
    private float destYaw = Float.NaN;
    private int closeTicks;

    public PortalEntity(EntityType<?> type, World world) {
        super(type, world);
        this.noClip = true;
        this.setNoGravity(true);
    }

    // ---------- configuração (servidor) ----------
    public void setup(UUID owner, PortalMode mode, long created, float scale) {
        this.owner = owner;
        this.mode = mode;
        this.created = created;
        this.dataTracker.set(SCALE, scale);
    }

    public float getPortalScale() {
        return dataTracker.get(SCALE);
    }

    public void setDestination(String dim, Vec3d pos, float yaw) {
        this.hasDest = true;
        this.destDim = dim;
        this.dx = pos.x;
        this.dy = pos.y;
        this.dz = pos.z;
        this.destYaw = yaw;
    }

    public String dimString() {
        return getWorld().getRegistryKey().getValue().toString();
    }

    /** Ponto de saída: 1,3 bloco à frente do portal. */
    public Vec3d exitPos() {
        double r = Math.toRadians(getYaw());
        double d = 0.5 + 0.8 * getPortalScale();
        return new Vec3d(getX() - Math.sin(r) * d, getY(), getZ() + Math.cos(r) * d);
    }

    public void link(PortalEntity other) {
        this.partner = other.getUuid();
        other.partner = this.getUuid();
        this.setDestination(other.dimString(), other.exitPos(), other.getYaw());
        other.setDestination(this.dimString(), this.exitPos(), this.getYaw());
    }

    public void close() {
        if (!isClosing()) dataTracker.set(CLOSING, true);
    }

    public boolean isClosing() {
        return dataTracker.get(CLOSING);
    }

    public UUID getOwner() { return owner; }
    public UUID getPartner() { return partner; }
    public PortalMode getMode() { return mode; }
    public long getCreated() { return created; }

    /** Escala de animação de abrir/fechar (0..1), usada pelo renderer. */
    public float getOpenScale(float tickDelta) {
        float s = isClosing()
                ? 1f - Math.min(1f, (closeTicks + tickDelta) / OPEN_TICKS)
                : Math.min(1f, (age + tickDelta) / OPEN_TICKS);
        return s * s * (3f - 2f * s);
    }

    // ---------- lógica ----------
    @Override
    public void tick() {
        super.tick();
        if (isClosing()) {
            closeTicks++;
            if (!getWorld().isClient && closeTicks >= OPEN_TICKS) discard();
            return;
        }
        if (getWorld().isClient || age < OPEN_TICKS || !hasDest) return;
        teleportOverlapping((ServerWorld) getWorld());
    }

    private void teleportOverlapping(ServerWorld world) {
        MinecraftServer server = world.getServer();
        double r = Math.toRadians(getYaw());
        double nx = -Math.sin(r), nz = Math.cos(r);   // normal do portal
        double tx = nz, tz = -nx;                      // tangente
        double sc = getPortalScale();
        Box box = getBoundingBox().expand(1.5);
        for (Entity e : world.getEntitiesByClass(Entity.class, box, this::canTeleport)) {
            double rx = e.getX() - getX(), rz = e.getZ() - getZ();
            double along = rx * tx + rz * tz;
            double depth = rx * nx + rz * nz;
            double ey = e.getY() + e.getHeight() * 0.5 - (getY() + 1.2 * sc);
            if (Math.abs(along) <= 0.9 * sc && Math.abs(depth) <= 0.45 && Math.abs(ey) <= 1.3 * sc) {
                send(server, world, e);
            }
        }
    }

    private boolean canTeleport(Entity e) {
        if (e == this || e instanceof PortalEntity || e.isSpectator() || e.hasVehicle() || !e.isAlive()) return false;
        MinecraftServer s = e.getServer();
        return s != null && !PortalService.onCooldown(e, s.getTicks());
    }

    private void send(MinecraftServer server, ServerWorld from, Entity e) {
        Identifier id = Identifier.tryParse(destDim);
        if (id == null) return;
        ServerWorld dest = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, id));
        if (dest == null) return;
        BlockPos target = BlockPos.ofFloored(dx, dy, dz);
        dest.getChunk(target); // força o carregamento do chunk de destino
        float yaw = Float.isNaN(destYaw) ? e.getYaw() : destYaw;
        PortalService.setCooldown(e, server.getTicks() + 40);
        from.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.6f);
        e.teleportTo(new TeleportTarget(dest, new Vec3d(dx, dy, dz), Vec3d.ZERO, yaw, e.getPitch(), TeleportTarget.NO_OP));
        dest.playSound(null, dx, dy, dz, SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.6f);
    }

    // ---------- boilerplate de entidade ----------
    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(CLOSING, false);
        builder.add(SCALE, 1.0f);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        owner = nbt.containsUuid("Owner") ? nbt.getUuid("Owner") : null;
        partner = nbt.containsUuid("Partner") ? nbt.getUuid("Partner") : null;
        mode = PortalMode.byName(nbt.getString("Mode"));
        created = nbt.getLong("Created");
        hasDest = nbt.getBoolean("HasDest");
        destDim = nbt.getString("DestDim");
        dx = nbt.getDouble("DX");
        dy = nbt.getDouble("DY");
        dz = nbt.getDouble("DZ");
        destYaw = nbt.contains("DestYaw") ? nbt.getFloat("DestYaw") : Float.NaN;
        dataTracker.set(SCALE, nbt.contains("Scale") ? nbt.getFloat("Scale") : 1.0f);
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        if (owner != null) nbt.putUuid("Owner", owner);
        if (partner != null) nbt.putUuid("Partner", partner);
        nbt.putString("Mode", mode.name());
        nbt.putLong("Created", created);
        nbt.putBoolean("HasDest", hasDest);
        nbt.putString("DestDim", destDim);
        nbt.putDouble("DX", dx);
        nbt.putDouble("DY", dy);
        nbt.putDouble("DZ", dz);
        if (!Float.isNaN(destYaw)) nbt.putFloat("DestYaw", destYaw);
        nbt.putFloat("Scale", getPortalScale());
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }
}
