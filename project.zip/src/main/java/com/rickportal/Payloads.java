package com.rickportal;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public final class Payloads {
    private Payloads() {}

    /** Cliente -> servidor: salva modo e destino na arma. dim vazio = sem destino. */
    public record Save(String mode, String dim, double x, double y, double z) implements CustomPayload {
        public static final Id<Save> ID = new Id<>(Identifier.of(RickPortal.MOD_ID, "save"));
        public static final PacketCodec<RegistryByteBuf, Save> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, Save::mode,
                PacketCodecs.STRING, Save::dim,
                PacketCodecs.DOUBLE, Save::x,
                PacketCodecs.DOUBLE, Save::y,
                PacketCodecs.DOUBLE, Save::z,
                Save::new);

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Cliente -> servidor: tamanho do portal e locais salvos. */
    public record Extras(float scale, String waypoints) implements CustomPayload {
        public static final Id<Extras> ID = new Id<>(Identifier.of(RickPortal.MOD_ID, "extras"));
        public static final PacketCodec<RegistryByteBuf, Extras> CODEC = PacketCodec.tuple(
                PacketCodecs.FLOAT, Extras::scale,
                PacketCodecs.STRING, Extras::waypoints,
                Extras::new);

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Cliente -> servidor: fecha todos os portais do jogador. */
    public record Clear() implements CustomPayload {
        public static final Id<Clear> ID = new Id<>(Identifier.of(RickPortal.MOD_ID, "clear"));
        public static final PacketCodec<RegistryByteBuf, Clear> CODEC = PacketCodec.unit(new Clear());

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Cliente -> servidor: autodestruir a arma. */
    public record Destruct() implements CustomPayload {
        public static final Id<Destruct> ID = new Id<>(Identifier.of(RickPortal.MOD_ID, "destruct"));
        public static final PacketCodec<RegistryByteBuf, Destruct> CODEC = PacketCodec.unit(new Destruct());

        @Override
        public Id<? extends CustomPayload> getId() { return ID; }
    }
}
