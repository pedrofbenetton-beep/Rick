package com.rickportal.client;

import com.rickportal.GunData;
import com.rickportal.Payloads;
import com.rickportal.PortalMode;
import com.rickportal.RickPortal;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Mapa + configurações da arma. Clique no mapa = escolhe o destino. Arrastar = mover. Scroll = zoom. */
public class PortalMapScreen extends Screen {
    private static final int[] SCALES = {1, 2, 4, 8, 16}; // blocos por pixel do mapa (128 px)
    private static final int GREEN = 0xFF9CFF6B;

    private PortalMode mode;
    private String dim;
    private boolean hasTarget;
    private double tx, ty, tz;
    private double cx, cz;
    private int zoomIdx = 1;
    private int portalScaleIdx;
    private final List<GunData.Waypoint> waypoints;
    private final List<GunData.Waypoint> history;
    private int wpIdx = -1, hiIdx = -1;
    private boolean armed, selfDestruct;

    private NativeImageBackedTexture tex;
    private Identifier texId;
    private boolean dirty = true;
    private long lastBuild;
    private boolean dragging, dragMoved;
    private double dragDist;
    private boolean suppress;

    private int mapX, mapY, mapSize, panelX, panelW, fieldsY;
    private ButtonWidget modeBtn, dimBtn, scaleBtn, wpBtn, hiBtn;
    private TextFieldWidget fx, fy, fz, nameField;
    private final List<String> dims = new ArrayList<>();

    public PortalMapScreen(GunData d) {
        super(Text.literal("Portal Gun"));
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        this.mode = d.mode();
        this.hasTarget = d.hasTarget();
        this.dim = d.hasTarget() ? d.dim() : mc.world.getRegistryKey().getValue().toString();
        this.tx = d.hasTarget() ? d.x() : Math.floor(p.getX()) + 0.5;
        this.ty = d.hasTarget() ? d.y() : p.getY();
        this.tz = d.hasTarget() ? d.z() : Math.floor(p.getZ()) + 0.5;
        this.cx = tx;
        this.cz = tz;
        this.portalScaleIdx = GunData.scaleIndex(d.scale());
        this.waypoints = new ArrayList<>(d.waypoints());
        this.history = new ArrayList<>(d.history());
    }

    private String currentDim() {
        return client.world.getRegistryKey().getValue().toString();
    }

    private int zoom() {
        return SCALES[zoomIdx];
    }

    private ButtonWidget btn(Text t, int x, int y, int w, ButtonWidget.PressAction a) {
        return addDrawableChild(ButtonWidget.builder(t, a).dimensions(x, y, w, 18).build());
    }

    @Override
    protected void init() {
        dims.clear();
        ClientPlayNetworkHandler h = client.getNetworkHandler();
        if (h != null && h.getWorldKeys() != null) {
            for (RegistryKey<World> k : h.getWorldKeys()) dims.add(k.getValue().toString());
        }
        if (!dims.contains(dim)) dims.add(dim);
        Collections.sort(dims);

        if (tex == null) {
            tex = new NativeImageBackedTexture(MapSampler.SIZE, MapSampler.SIZE, true);
            texId = Identifier.of(RickPortal.MOD_ID, "dynamic/portal_map");
            client.getTextureManager().registerTexture(texId, tex);
        }

        mapX = 10;
        mapY = 20;
        mapSize = Math.max(80, Math.min(height - mapY - 46, width - 10 - 12 - 150 - 10));
        panelX = mapX + mapSize + 12;
        panelW = Math.max(130, width - panelX - 10);
        int half = (panelW - 4) / 2;
        int x2 = panelX + half + 4;

        int y = 4;
        modeBtn = btn(modeText(), panelX, y, panelW, b -> {
            mode = mode.next();
            b.setMessage(modeText());
        });
        y += 20;
        dimBtn = btn(dimText(), panelX, y, panelW, b -> {
            int i = dims.indexOf(dim);
            dim = dims.get((i + 1) % dims.size());
            hasTarget = true;
            b.setMessage(dimText());
            dirty = true;
        });
        y += 22;

        fieldsY = y;
        fx = field(y);
        y += 20;
        fy = field(y);
        y += 20;
        fz = field(y);
        y += 22;
        fx.setChangedListener(s -> {
            if (suppress) return;
            Integer v = parse(s);
            if (v != null) { tx = v + 0.5; hasTarget = true; }
        });
        fy.setChangedListener(s -> {
            if (suppress) return;
            Integer v = parse(s);
            if (v != null) { ty = v; hasTarget = true; }
        });
        fz.setChangedListener(s -> {
            if (suppress) return;
            Integer v = parse(s);
            if (v != null) { tz = v + 0.5; hasTarget = true; }
        });

        btn(Text.literal("Meu local"), panelX, y, half, b -> {
            ClientPlayerEntity p = client.player;
            applyTarget(currentDim(), Math.floor(p.getX()) + 0.5, p.getY(), Math.floor(p.getZ()) + 0.5);
        });
        btn(Text.literal("Centrar"), x2, y, half, b -> {
            cx = tx;
            cz = tz;
            dirty = true;
        });
        y += 20;
        btn(Text.literal("Sem destino"), panelX, y, half, b -> hasTarget = false);
        scaleBtn = btn(scaleText(), x2, y, half, b -> {
            portalScaleIdx = (portalScaleIdx + 1) % GunData.SCALES.length;
            b.setMessage(scaleText());
        });
        y += 22;

        nameField = new TextFieldWidget(textRenderer, panelX, y, panelW, 18, Text.literal("Nome"));
        nameField.setMaxLength(16);
        nameField.setPlaceholder(Text.literal("Nome do local salvo"));
        addDrawableChild(nameField);
        y += 20;
        btn(Text.literal("Salvar local"), panelX, y, half, b -> saveWaypoint());
        btn(Text.literal("Apagar salvo"), x2, y, half, b -> deleteWaypoint());
        y += 20;
        wpBtn = btn(wpText(), panelX, y, half, b -> {
            if (waypoints.isEmpty()) return;
            wpIdx = (wpIdx + 1) % waypoints.size();
            GunData.Waypoint w = waypoints.get(wpIdx);
            applyTarget(w.dim(), w.x(), w.y(), w.z());
            b.setMessage(wpText());
        });
        hiBtn = btn(hiText(), x2, y, half, b -> {
            if (history.isEmpty()) return;
            hiIdx = (hiIdx + 1) % history.size();
            GunData.Waypoint w = history.get(hiIdx);
            applyTarget(w.dim(), w.x(), w.y(), w.z());
            b.setMessage(hiText());
        });
        y += 22;
        btn(Text.literal("Fechar portais"), panelX, y, half, b -> ClientPlayNetworking.send(new Payloads.Clear()));
        btn(Text.literal("Autodestruir"), x2, y, half, b -> {
            if (!armed) {
                armed = true;
                b.setMessage(Text.literal("Confirmar?"));
            } else {
                selfDestruct = true;
                ClientPlayNetworking.send(new Payloads.Destruct());
                close();
            }
        });
        y += 22;
        btn(Text.literal("Salvar e fechar"), panelX, y, panelW, b -> close());

        updateFields();
    }

    private TextFieldWidget field(int y) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, panelX + 14, y, panelW - 14, 18, Text.literal("coord"));
        f.setMaxLength(9);
        f.setTextPredicate(s -> s.matches("-?\\d{0,8}"));
        addDrawableChild(f);
        return f;
    }

    private static Integer parse(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return null;
        }
    }

    private void applyTarget(String d, double x, double y, double z) {
        dim = d;
        if (!dims.contains(d)) dims.add(d);
        tx = x;
        ty = y;
        tz = z;
        hasTarget = true;
        cx = tx;
        cz = tz;
        dimBtn.setMessage(dimText());
        updateFields();
        dirty = true;
    }

    private void saveWaypoint() {
        if (waypoints.size() >= GunData.MAX_WAYPOINTS) return;
        String name = nameField.getText().trim();
        if (name.isEmpty()) name = "Local " + (waypoints.size() + 1);
        waypoints.add(new GunData.Waypoint(name, dim, tx, ty, tz));
        wpIdx = waypoints.size() - 1;
        nameField.setText("");
        wpBtn.setMessage(wpText());
    }

    private void deleteWaypoint() {
        if (wpIdx < 0 || wpIdx >= waypoints.size()) return;
        waypoints.remove(wpIdx);
        wpIdx = waypoints.isEmpty() ? -1 : Math.min(wpIdx, waypoints.size() - 1);
        wpBtn.setMessage(wpText());
    }

    private void updateFields() {
        suppress = true;
        fx.setText(String.valueOf((int) Math.floor(tx)));
        fy.setText(String.valueOf((int) Math.floor(ty)));
        fz.setText(String.valueOf((int) Math.floor(tz)));
        suppress = false;
    }

    private Text modeText() {
        return Text.literal("Modo: " + mode.label);
    }

    private Text dimText() {
        String s = dim.contains(":") ? dim.substring(dim.indexOf(':') + 1) : dim;
        return Text.literal("Dimensão: " + s.replace('_', ' '));
    }

    private Text scaleText() {
        return Text.literal("Portal: " + GunData.SCALES[portalScaleIdx] + "x");
    }

    private Text wpText() {
        int w = (panelW - 4) / 2 - 8;
        String s = (wpIdx >= 0 && wpIdx < waypoints.size())
                ? waypoints.get(wpIdx).name() : "Salvos (" + waypoints.size() + ")";
        return Text.literal(textRenderer.trimToWidth(s, w));
    }

    private Text hiText() {
        String s = "Histórico (" + history.size() + ")";
        if (hiIdx >= 0 && hiIdx < history.size()) s = "Hist. " + (hiIdx + 1) + "/" + history.size();
        return Text.literal(s);
    }

    // ---------- desenho ----------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        long now = System.currentTimeMillis();
        boolean same = dim.equals(currentDim());
        if (same && now - lastBuild > 1500) dirty = true;
        if (same && dirty && now - lastBuild > 80) rebuild(now);

        ctx.drawTextWithShadow(textRenderer, Text.literal("Portal Gun - clique no mapa para escolher o destino"), mapX, 6, GREEN);
        ctx.fill(mapX - 1, mapY - 1, mapX + mapSize + 1, mapY + mapSize + 1, 0xFF000000);
        if (same) {
            ctx.drawTexture(texId, mapX, mapY, mapSize, mapSize, 0f, 0f,
                    MapSampler.SIZE, MapSampler.SIZE, MapSampler.SIZE, MapSampler.SIZE);
        } else {
            ctx.fill(mapX, mapY, mapX + mapSize, mapY + mapSize, 0xFF1A1A1A);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Sem prévia desta dimensão"),
                    mapX + mapSize / 2, mapY + mapSize / 2 - 10, 0xFFAAAAAA);
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Use as coordenadas ao lado"),
                    mapX + mapSize / 2, mapY + mapSize / 2 + 2, 0xFFAAAAAA);
        }
        ctx.drawBorder(mapX - 1, mapY - 1, mapSize + 2, mapSize + 2, GREEN);

        if (same) {
            ClientPlayerEntity p = client.player;
            int psx = sx(p.getX()), psz = sz(p.getZ());
            if (inMap(psx, psz)) {
                ctx.fill(psx - 2, psz - 2, psx + 3, psz + 3, 0xFF000000);
                ctx.fill(psx - 1, psz - 1, psx + 2, psz + 2, 0xFFFFFFFF);
            }
            for (GunData.Waypoint w : waypoints) {
                if (!w.dim().equals(dim)) continue;
                int wsx = sx(w.x()), wsz = sz(w.z());
                if (inMap(wsx, wsz)) ctx.fill(wsx - 1, wsz - 1, wsx + 2, wsz + 2, 0xFFFFD84A);
            }
            if (hasTarget) {
                int tsx = sx(tx), tsz = sz(tz);
                if (inMap(tsx, tsz)) {
                    ctx.fill(tsx - 5, tsz - 1, tsx + 6, tsz + 2, 0xFF000000);
                    ctx.fill(tsx - 1, tsz - 5, tsx + 2, tsz + 6, 0xFF000000);
                    ctx.fill(tsx - 4, tsz, tsx + 5, tsz + 1, 0xFFFF3030);
                    ctx.fill(tsx, tsz - 4, tsx + 1, tsz + 5, 0xFFFF3030);
                }
            }
        }

        int span = MapSampler.SIZE * zoom();
        String info = "Zoom: " + zoom() + " bloco(s)/px  |  " + span + " blocos";
        if (inMap(mx, my)) {
            int wx = (int) Math.floor(cx - span / 2.0 + (mx - mapX) / (double) mapSize * span);
            int wz = (int) Math.floor(cz - span / 2.0 + (my - mapY) / (double) mapSize * span);
            info = "X " + wx + "  Z " + wz + "  |  " + info;
        }
        ctx.drawTextWithShadow(textRenderer, Text.literal(info), mapX, mapY + mapSize + 5, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, Text.literal(hasTarget ? "Destino definido (vermelho)" : "Sem destino"),
                mapX, mapY + mapSize + 16, hasTarget ? GREEN : 0xFFAAAAAA);
        int ly = mapY + mapSize + 27;
        for (OrderedText line : textRenderer.wrapLines(Text.literal(mode.description), Math.max(mapSize, 200))) {
            ctx.drawTextWithShadow(textRenderer, line, mapX, ly, 0xFFBBBBBB);
            ly += 10;
        }

        ctx.drawTextWithShadow(textRenderer, Text.literal("X"), panelX, fieldsY + 5, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Y"), panelX, fieldsY + 25, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Z"), panelX, fieldsY + 45, 0xFFFFFFFF);
    }

    private void rebuild(long now) {
        if (client.world == null || tex.getImage() == null) return;
        MapSampler.render(client.world, tex.getImage(), (int) Math.floor(cx), (int) Math.floor(cz),
                zoom(), (int) client.player.getY());
        tex.upload();
        dirty = false;
        lastBuild = now;
    }

    private int sx(double wx) {
        double span = MapSampler.SIZE * zoom();
        return (int) (mapX + (wx - (cx - span / 2.0)) / span * mapSize);
    }

    private int sz(double wz) {
        double span = MapSampler.SIZE * zoom();
        return (int) (mapY + (wz - (cz - span / 2.0)) / span * mapSize);
    }

    private boolean inMap(double x, double y) {
        return x >= mapX && y >= mapY && x < mapX + mapSize && y < mapY + mapSize;
    }

    // ---------- entrada ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && inMap(mx, my)) {
            dragging = true;
            dragMoved = false;
            dragDist = 0;
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            dragDist += Math.abs(dx) + Math.abs(dy);
            if (dragDist > 3) dragMoved = true;
            if (dragMoved) {
                double span = MapSampler.SIZE * zoom();
                cx -= dx / mapSize * span;
                cz -= dy / mapSize * span;
                dirty = true;
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0 && dragging) {
            dragging = false;
            if (!dragMoved && inMap(mx, my)) pick(mx, my);
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void pick(double mx, double my) {
        double span = MapSampler.SIZE * zoom();
        int wx = (int) Math.floor(cx - span / 2.0 + (mx - mapX) / mapSize * span);
        int wz = (int) Math.floor(cz - span / 2.0 + (my - mapY) / mapSize * span);
        tx = wx + 0.5;
        tz = wz + 0.5;
        if (dim.equals(currentDim())) {
            int y = MapSampler.surfaceFreeY(client.world, wx, wz, (int) client.player.getY());
            if (y != Integer.MIN_VALUE) ty = y;
        }
        hasTarget = true;
        updateFields();
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (inMap(mx, my)) {
            zoomIdx = vAmount > 0 ? Math.max(0, zoomIdx - 1) : Math.min(SCALES.length - 1, zoomIdx + 1);
            dirty = true;
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public void removed() {
        if (!selfDestruct && client != null && client.player != null) {
            ClientPlayNetworking.send(new Payloads.Save(mode.name(), hasTarget ? dim : "", tx, ty, tz));
            ClientPlayNetworking.send(new Payloads.Extras(GunData.SCALES[portalScaleIdx], GunData.encode(waypoints)));
        }
        if (texId != null && client != null) client.getTextureManager().destroyTexture(texId);
        super.removed();
    }
}
