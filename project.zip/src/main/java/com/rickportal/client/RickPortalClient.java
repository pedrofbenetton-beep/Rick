package com.rickportal.client;

import com.rickportal.GunData;
import com.rickportal.Payloads;
import com.rickportal.PortalGunItem;
import com.rickportal.RickPortal;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.ItemStack;
import org.lwjgl.glfw.GLFW;

public class RickPortalClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(RickPortal.PORTAL_ENTITY, PortalRenderer::new);

        PortalGunItem.OPEN_CONFIG = stack ->
                MinecraftClient.getInstance().setScreen(new PortalMapScreen(GunData.read(stack)));

        // Shift + botão esquerdo com a arma: abre mapa/configurações
        ClientPreAttackCallback.EVENT.register((client, player, clickCount) -> {
            if (client.currentScreen != null || !player.isSneaking()) return false;
            ItemStack gun = PortalGunItem.findGun(player);
            if (gun.isEmpty()) return false;
            PortalGunItem.OPEN_CONFIG.accept(gun);
            return true;
        });

        // Tecla R com a arma: fecha todos os portais
        KeyBinding closeKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.rickportal.close_all", GLFW.GLFW_KEY_R, "category.rickportal"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (closeKey.wasPressed()) {
                if (client.player != null && !PortalGunItem.findGun(client.player).isEmpty()) {
                    ClientPlayNetworking.send(new Payloads.Clear());
                }
            }
        });
    }
}
