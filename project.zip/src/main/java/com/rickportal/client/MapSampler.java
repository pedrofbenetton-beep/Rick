package com.rickportal.client;

import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.Arrays;

/** Mapa de cima (estilo mapa do jogo) só dos chunks já carregados no cliente. Barato: 128x128 colunas, só quando muda. */
public final class MapSampler {
    public static final int SIZE = 128;

    private MapSampler() {}

    /** Y livre logo acima da superfície, ou Integer.MIN_VALUE se o chunk não está carregado. */
    public static int surfaceFreeY(World world, int x, int z, int refY) {
        Chunk chunk = world.getChunk(x >> 4, z >> 4, ChunkStatus.FULL, false);
        return surfaceFreeY(world, chunk, x, z, refY);
    }

    private static int surfaceFreeY(World world, Chunk chunk, int x, int z, int refY) {
        if (chunk == null) return Integer.MIN_VALUE;
        int bottom = world.getBottomY();
        if (world.getDimension().hasCeiling()) { // Nether: acha o chão perto da altura do jogador
            int y = Math.min(refY + 8, world.getTopY() - 1);
            int limit = Math.max(bottom, refY - 48);
            BlockPos.Mutable p = new BlockPos.Mutable(x, y, z);
            for (; y > limit; y--) {
                p.setY(y - 1);
                if (!chunk.getBlockState(p).isAir()) return y;
            }
            return Math.max(limit, bottom);
        }
        return chunk.sampleHeightmap(Heightmap.Type.WORLD_SURFACE, x & 15, z & 15);
    }

    public static void render(ClientWorld world, NativeImage img, int cx, int cz, int scale, int refY) {
        int half = SIZE * scale / 2;
        int x0 = cx - half, z0 = cz - half;
        int[] prev = new int[SIZE];
        Arrays.fill(prev, Integer.MIN_VALUE);
        Chunk chunk = null;
        int ccx = Integer.MIN_VALUE, ccz = Integer.MIN_VALUE;
        BlockPos.Mutable pos = new BlockPos.Mutable();
        BlockPos.Mutable pos2 = new BlockPos.Mutable();

        for (int py = 0; py < SIZE; py++) {
            int wz = z0 + py * scale;
            for (int px = 0; px < SIZE; px++) {
                int wx = x0 + px * scale;
                int chx = wx >> 4, chz = wz >> 4;
                if (chunk == null || chx != ccx || chz != ccz) {
                    chunk = world.getChunk(chx, chz, ChunkStatus.FULL, false);
                    ccx = chx;
                    ccz = chz;
                }
                int argb;
                if (chunk == null) {
                    argb = (((chx + chz) & 1) == 0) ? 0xFF2B2B2B : 0xFF333333;
                } else {
                    int y = surfaceFreeY(world, chunk, wx, wz, refY);
                    pos.set(wx, y - 1, wz);
                    argb = colorOf(world, chunk, pos, pos2, y, prev[px]);
                    prev[px] = y;
                }
                img.setColor(px, py, toAbgr(argb));
            }
        }
    }

    private static int colorOf(ClientWorld world, Chunk chunk, BlockPos.Mutable pos, BlockPos.Mutable tmp, int y, int prevY) {
        BlockState st = chunk.getBlockState(pos);
        MapColor mc = st.getMapColor(world, pos);
        if (st.isAir() || mc == MapColor.CLEAR) return 0xFF000000;
        float shade;
        if (!st.getFluidState().isEmpty()) {
            int depth = 0;
            tmp.set(pos);
            while (depth < 10) {
                tmp.setY(tmp.getY() - 1);
                if (chunk.getBlockState(tmp).getFluidState().isEmpty()) break;
                depth++;
            }
            shade = Math.max(0.45f, 1f - depth * 0.06f);
        } else if (prevY == Integer.MIN_VALUE) {
            shade = 0.86f;
        } else {
            int diff = y - prevY;
            shade = diff > 0 ? 1.0f : (diff < 0 ? 0.70f : 0.86f);
        }
        int rgb = mc.color;
        int r = (int) (((rgb >> 16) & 255) * shade);
        int g = (int) (((rgb >> 8) & 255) * shade);
        int b = (int) ((rgb & 255) * shade);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int toAbgr(int argb) {
        int a = (argb >>> 24) & 255, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }
}
