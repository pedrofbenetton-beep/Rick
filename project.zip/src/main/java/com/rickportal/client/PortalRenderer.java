package com.rickportal.client;

import com.rickportal.PortalEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

/** Desenha o portal verde animado (espiral girando + borda ondulante + brilho), sem texturas. */
public class PortalRenderer extends EntityRenderer<PortalEntity> {
    private static final int RINGS = 9;
    private static final int SEGS = 32;
    private static final float RX = 0.95f, RY = 1.25f;
    private static final float TAU = (float) (Math.PI * 2);
    private static final float RIM = 0.88f;

    public PortalRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0f;
    }

    @Override
    public Identifier getTexture(PortalEntity entity) {
        return Identifier.of("minecraft", "textures/misc/white.png");
    }

    @Override
    public void render(PortalEntity e, float yaw, float td, MatrixStack m, VertexConsumerProvider vcp, int light) {
        float open = e.getOpenScale(td);
        if (open <= 0.01f) return;
        float ps = e.getPortalScale();
        float scale = open * ps;
        float t = e.age + td;

        m.push();
        m.translate(0, 1.2 * ps, 0);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-e.getYaw()));
        m.scale(scale, scale, scale);
        Matrix4f mat = m.peek().getPositionMatrix();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLightning());

        // Interior em espiral
        for (int i = 0; i < RINGS; i++) {
            float u0 = i / (float) RINGS * RIM, u1 = (i + 1) / (float) RINGS * RIM;
            float spin = t * 0.05f * (i % 2 == 0 ? 1f : -1.3f) * (1f + i * 0.15f);
            float depth = 0.6f + 0.4f * (i / (float) RINGS);
            for (int j = 0; j < SEGS; j++) {
                float a0 = j / (float) SEGS * TAU + spin, a1 = (j + 1) / (float) SEGS * TAU + spin;
                float f = 0.5f + 0.5f * MathHelper.sin(a0 * 3f + i * 0.9f);
                int c = argb(0.85f, (0.05f + 0.35f * f) * depth, (0.35f + 0.6f * f) * depth, (0.05f + 0.15f * f) * depth);
                quad(vc, mat,
                        px(u0, a0), py(u0, a0), c, px(u0, a1), py(u0, a1), c,
                        px(u1, a1), py(u1, a1), c, px(u1, a0), py(u1, a0), c);
            }
        }

        // Borda brilhante ondulante + halo
        int rimC = argb(0.95f, 0.65f, 1.0f, 0.35f);
        int haloIn = argb(0.5f, 0.4f, 1.0f, 0.2f);
        int haloOut = argb(0.0f, 0.4f, 1.0f, 0.2f);
        for (int j = 0; j < SEGS; j++) {
            float a0 = j / (float) SEGS * TAU, a1 = (j + 1) / (float) SEGS * TAU;
            float w0 = wobble(a0, t), w1 = wobble(a1, t);
            quad(vc, mat,
                    px(RIM, a0), py(RIM, a0), rimC, px(RIM, a1), py(RIM, a1), rimC,
                    px(w1, a1), py(w1, a1), rimC, px(w0, a0), py(w0, a0), rimC);
            quad(vc, mat,
                    px(w0, a0), py(w0, a0), haloIn, px(w1, a1), py(w1, a1), haloIn,
                    px(w1 + 0.22f, a1), py(w1 + 0.22f, a1), haloOut, px(w0 + 0.22f, a0), py(w0 + 0.22f, a0), haloOut);
        }
        m.pop();
    }

    private static float wobble(float a, float t) {
        return 1f + 0.04f * MathHelper.sin(a * 7f + t * 0.4f) + 0.03f * MathHelper.sin(a * 13f - t * 0.5f);
    }

    private static float px(float u, float a) { return MathHelper.cos(a) * RX * u; }
    private static float py(float u, float a) { return MathHelper.sin(a) * RY * u; }

    private static int c(float v) { return Math.max(0, Math.min(255, (int) (v * 255f))); }
    private static int argb(float a, float r, float g, float b) { return (c(a) << 24) | (c(r) << 16) | (c(g) << 8) | c(b); }

    /** Quad desenhado dos dois lados (a camada não tem culling garantido). */
    private static void quad(VertexConsumer vc, Matrix4f m,
                             float x0, float y0, int c0, float x1, float y1, int c1,
                             float x2, float y2, int c2, float x3, float y3, int c3) {
        vc.vertex(m, x0, y0, 0f).color(c0);
        vc.vertex(m, x1, y1, 0f).color(c1);
        vc.vertex(m, x2, y2, 0f).color(c2);
        vc.vertex(m, x3, y3, 0f).color(c3);
        vc.vertex(m, x3, y3, 0f).color(c3);
        vc.vertex(m, x2, y2, 0f).color(c2);
        vc.vertex(m, x1, y1, 0f).color(c1);
        vc.vertex(m, x0, y0, 0f).color(c0);
    }
}
