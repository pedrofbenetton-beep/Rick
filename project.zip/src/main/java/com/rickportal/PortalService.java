package com.rickportal;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.*;

public final class PortalService {
    public static final int STACK_LIMIT = 3;   // LIFO / FIFO
    public static final int PAIR_LIMIT = 4;    // MULTIPAIRS (2 pares)
    public static final int BASE_LIMIT = 10;   // BASE

    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();

    private PortalService() {}

    public static boolean onCooldown(Entity e, int nowTick) {
        Integer until = COOLDOWN.get(e.getUuid());
        return until != null && nowTick < until;
    }

    public static void setCooldown(Entity e, int untilTick) {
        COOLDOWN.put(e.getUuid(), untilTick);
        if (COOLDOWN.size() > 512) COOLDOWN.values().removeIf(v -> v < untilTick - 200);
    }

    /** Portais do jogador (carregados) naquele modo, do mais antigo ao mais novo. */
    private static List<PortalEntity> owned(MinecraftServer server, UUID owner, PortalMode mode) {
        List<PortalEntity> list = new ArrayList<>();
        for (ServerWorld w : server.getWorlds()) {
            list.addAll(w.getEntitiesByType(TypeFilter.instanceOf(PortalEntity.class),
                    p -> owner.equals(p.getOwner()) && p.getMode() == mode && !p.isClosing()));
        }
        list.sort(Comparator.comparingLong(PortalEntity::getCreated));
        return list;
    }

    public static void clearAll(ServerPlayerEntity player) {
        for (ServerWorld w : player.getServer().getWorlds()) {
            for (PortalEntity p : w.getEntitiesByType(TypeFilter.instanceOf(PortalEntity.class),
                    e -> player.getUuid().equals(e.getOwner()) && !e.isClosing())) {
                p.close();
            }
        }
        player.sendMessage(Text.literal("Todos os seus portais foram fechados."), true);
    }

    private static ItemStack findFuel(ServerPlayerEntity player) {
        if (player.getOffHandStack().isOf(RickPortal.PORTAL_FLUID)) return player.getOffHandStack();
        if (player.getMainHandStack().isOf(RickPortal.PORTAL_FLUID)) return player.getMainHandStack();
        return ItemStack.EMPTY;
    }

    public static void shoot(ServerPlayerEntity player, ServerWorld world, ItemStack stack) {
        boolean creative = player.isCreative();
        ItemStack fuel = ItemStack.EMPTY;
        if (!creative) {
            fuel = findFuel(player);
            if (fuel.isEmpty()) {
                player.sendMessage(Text.literal("Sem fluido de portal: segure um bulbo na outra mão."), true);
                return;
            }
        }
        if (doShoot(player, world, stack) && !creative) {
            EquipmentSlot slot = fuel == player.getOffHandStack() ? EquipmentSlot.OFFHAND : EquipmentSlot.MAINHAND;
            fuel.damage(1, player, slot);
        }
    }

    /** @return true se um portal foi realmente aberto (para gastar combustível). */
    private static boolean doShoot(ServerPlayerEntity player, ServerWorld world, ItemStack stack) {
        GunData d = GunData.read(stack);
        MinecraftServer server = world.getServer();
        PortalMode mode = d.mode();
        List<PortalEntity> mine = owned(server, player.getUuid(), mode);

        if (mode != PortalMode.PAIRS && !d.hasTarget()) {
            player.sendMessage(Text.literal("Defina um destino: Shift + botão direito/esquerdo."), true);
            return false;
        }

        switch (mode) {
            case LIFO -> {
                if (mine.size() >= STACK_LIMIT) mine.get(mine.size() - 1).close();
                openToTarget(player, world, d, mode);
                remember(stack, d);
                return true;
            }
            case FIFO -> {
                if (mine.size() >= STACK_LIMIT) mine.get(0).close();
                openToTarget(player, world, d, mode);
                remember(stack, d);
                return true;
            }
            case BASE -> {
                if (mine.size() >= BASE_LIMIT) {
                    player.sendMessage(Text.literal("Limite de " + BASE_LIMIT + " portais atingido (Shift + clique > Fechar portais)."), true);
                    return false;
                }
                openToTarget(player, world, d, mode);
                remember(stack, d);
                return true;
            }
            case PAIRS -> {
                PortalEntity pending = mine.stream().filter(p -> p.getPartner() == null).findFirst().orElse(null);
                if (pending != null) {
                    PortalEntity second;
                    if (d.hasTarget()) {
                        ServerWorld tw = worldOf(server, d.dim());
                        if (tw == null) {
                            player.sendMessage(Text.literal("Dimensão de destino inválida."), true);
                            return false;
                        }
                        tw.getChunk(BlockPos.ofFloored(d.x(), d.y(), d.z()));
                        second = spawn(tw, player, mode, d.x(), d.y(), d.z(), player.getYaw(), d.scale());
                        remember(stack, d);
                    } else {
                        second = spawnInFront(player, world, mode, d.scale());
                    }
                    pending.link(second);
                } else {
                    if (mine.size() >= PAIR_LIMIT) {
                        PortalEntity old = mine.get(0);
                        old.close();
                        mine.stream().filter(p -> p.getUuid().equals(old.getPartner())).findFirst().ifPresent(PortalEntity::close);
                    }
                    spawnInFront(player, world, mode, d.scale());
                }
                return true;
            }
        }
        return false;
    }

    /** Guarda o destino no histórico da arma (mais recente primeiro, máx. 10). */
    private static void remember(ItemStack stack, GunData d) {
        GunData.Waypoint w = new GunData.Waypoint("", d.dim(), d.x(), d.y(), d.z());
        List<GunData.Waypoint> h = new ArrayList<>(d.history());
        h.removeIf(o -> o.dim().equals(w.dim())
                && Math.floor(o.x()) == Math.floor(w.x())
                && Math.floor(o.y()) == Math.floor(w.y())
                && Math.floor(o.z()) == Math.floor(w.z()));
        h.add(0, w);
        while (h.size() > GunData.MAX_HISTORY) h.remove(h.size() - 1);
        new GunData(d.mode(), d.hasTarget(), d.dim(), d.x(), d.y(), d.z(), d.scale(), d.waypoints(), h).write(stack);
    }

    private static void openToTarget(ServerPlayerEntity player, ServerWorld world, GunData d, PortalMode mode) {
        PortalEntity p = spawnInFront(player, world, mode, d.scale());
        p.setDestination(d.dim(), new Vec3d(d.x(), d.y(), d.z()), Float.NaN);
    }

    private static ServerWorld worldOf(MinecraftServer server, String dim) {
        Identifier id = Identifier.tryParse(dim);
        return id == null ? null : server.getWorld(RegistryKey.of(RegistryKeys.WORLD, id));
    }

    private static PortalEntity spawnInFront(ServerPlayerEntity player, ServerWorld world, PortalMode mode, float scale) {
        double r = Math.toRadians(player.getYaw());
        Vec3d fwd = new Vec3d(-Math.sin(r), 0, Math.cos(r));
        Vec3d start = player.getPos().add(0, 1.0, 0);
        double maxDist = 3.0 + scale;
        Vec3d end = start.add(fwd.multiply(maxDist));
        double dist = maxDist;
        var hit = world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, player));
        if (hit.getType() == HitResult.Type.BLOCK) {
            dist = Math.max(1.5, Math.min(maxDist, hit.getPos().distanceTo(start) - 0.6));
        }
        return spawn(world, player, mode,
                player.getX() + fwd.x * dist, player.getY(), player.getZ() + fwd.z * dist,
                player.getYaw() + 180f, scale);
    }

    private static PortalEntity spawn(ServerWorld w, ServerPlayerEntity owner, PortalMode mode,
                                      double x, double y, double z, float yaw, float scale) {
        PortalEntity p = new PortalEntity(RickPortal.PORTAL_ENTITY, w);
        p.refreshPositionAndAngles(x, y, z, yaw, 0f);
        p.setup(owner.getUuid(), mode, System.currentTimeMillis(), scale);
        w.spawnEntity(p);
        w.playSound(null, x, y, z, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.PLAYERS, 0.2f, 2.0f);
        return p;
    }
}
