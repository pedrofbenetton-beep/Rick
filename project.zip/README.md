# Portal Gun (Fabric 1.21.1)

Compile com o GitHub Actions (veja o passo a passo da conversa) ou com `gradle build`.
O .jar sai em build/libs/ (use o que NÃO termina em -sources).

## Uso
- Botão direito: abre um portal. Em modo Survival gasta 1 carga do bulbo de fluido (mão oposta).
- Shift + botão direito/esquerdo: mapa e configurações.
- Tecla R com a arma: fecha todos os portais.
- Craft: bulbo = garrafa de vidro + slime + pérola do Ender. Arma: ver receita (ou /give @s rickportal:portal_gun).
- No menu: modos LIFO/FIFO/MULTIPAIRS/BASE, dimensão, coordenadas, tamanho do portal, locais salvos,
  histórico, fechar portais e autodestruir.
